package com.example.test1;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class streg extends AppCompatActivity implements AdapterView.OnItemSelectedListener, RadioGroup.OnCheckedChangeListener {
    TextView Welcome,Fees,Hours,TFees,THrs,Total;
    Button add,reg;
    RadioGroup rg1;
    RadioButton grad,unGrad;
    CheckBox accomd,MedicalInsur;
    Spinner spCourse;
    String Course[] = {"Java", "Swift", "iOS", "Android", "Database"};
    String Feess[] = {"1300", "1500", "1350", "1400", "1000"};
    String Hourss[]= { "6","5","5","7","4"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Welcome.setText("Welcome "+ MainActivity.t11.getText());
        Fees = findViewById(R.id.textView5);
        Hours = findViewById(R.id.textView6);
        TFees = findViewById(R.id.tfee);
        THrs = findViewById(R.id.thh);
        rg1 = findViewById(R.id.radioGroup);
        unGrad = findViewById(R.id.radioButton2);
        grad = findViewById(R.id.radioButton);
        accomd = findViewById(R.id.checkBox);
        MedicalInsur = findViewById(R.id.checkBox2);
        spCourse = findViewById(R.id.spinner);
        add = findViewById(R.id.button2);
        reg = findViewById(R.id.button);
        rg1.setOnCheckedChangeListener(this);
        spCourse.setOnItemSelectedListener(this);
        add.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int n1 = Integer.parseInt(Fees.getText().toString());
            int n2 = Integer.parseInt(Hours.getText().toString());

            int x = + n1;
            int y = n2;
            TFees.setText(String.format("%d", x));
            THrs.setText(String.format("%d", y));
       }
    });
reg.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int i=spCourse.getSelectedItemPosition();
            Fees.setText(Feess[i]);
            Hours.setText(Hourss[i]);
            int ext= 0;
            int n1 = Integer.parseInt(TFees.getText().toString());
            int n2 = Integer.parseInt(THrs.getText().toString());
            if(accomd.isChecked()){
                ext = ext+n1;

            }
            if(MedicalInsur.isChecked()){
                ext = ext+n1;
            }

        }
    });
}

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        Fees.setText(Feess[i]);
        Hours.setText(Hourss[i]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(RadioGroup rg1, int i) {

        int n = Integer.parseInt(THrs.getText().toString());
        switch(i){
            case R.id.radioButton:
                if(n > 21){
                    Toast.makeText(streg.this, "You cannot have more than 21 hours", Toast.LENGTH_SHORT).show();
                    reg.setEnabled(false);
                }else{
                    reg.setEnabled(true);
                }

                break;
            case R.id.radioButton2:
                if(n>19){
                    Toast.makeText(streg.this, "You cannot have more than 19 hours", Toast.LENGTH_SHORT).show();
                    reg.setEnabled(false);
                }
                else{
                    reg.setEnabled(true);
                }
                break;
        }

    }
}
